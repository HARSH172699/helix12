import React from 'react'

const Alumni = () => {
  return (
    <div>Alumni</div>
  )
}

export default Alumni