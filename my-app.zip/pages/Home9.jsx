import React from 'react'

const Home9 = () => {
  return (
    <section className="callto-action-area bg-theme">
    <div className="container">
      <div className="row">
        <div className="col-lg-10 offset-lg-1 col-12 offset-0">
          <div className="callto-action">
            <div className="callto-action-inner">
              <h2>To start your project with us</h2>
              <a href="#" className="cr-btn cr-btn-white">
                <span>Contact Us</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  )
}

export default Home9