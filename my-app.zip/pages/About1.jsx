import React from 'react'

const About1 = () => {
  return (
   < >
   <div className="about1">
   <h2> our History</h2>
   </div>
   <div className="abouttg">
       <div className="container">
       <p>Helix Tech-IT Solutions was founded to bridge the gap between IT candidates and the companies that need them. 

Quality IT professionals are great at their profession, but that doesn t mean they re great at finding work. Many top universities produce reliable professionals, but don t equip them with the skills to find a position that maximizes their talent. Thats where Helix Tech-IT Solutions comes in.

We help to not only find the very best in IT talent but also match them with companies they can grow and evolve with. Were building a leading IT community by combining job-seeking, qualified candidates and organizations in need of their services. Our expertise expands across North America to include the United States and Canada. No matter where youre located, our highly experienced and talented team is here to help. </p>
       </div>
   </div>
   </>
  )
}

export default About1