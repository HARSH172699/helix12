import React from 'react'
import Navbar from '../Components/Navbar'
import Carasoul from './Carasoul'
import Home2 from './Home2'
import Home3 from './Home3'
import Home4 from './Home4'
import Home5 from './Home5'
import Home7 from './Home7'
import Footer from './Footer'
const Home = () => {
  return (
    <>
     <Navbar/>
  <Carasoul/>
  
  <Home3/>
  <Home2/>
  <Home4/>
  <Home5/>
 <Home7/>

 <Footer/>
    
    </>
  )
}

export default Home