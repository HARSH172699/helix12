import React from 'react'

const applynow = () => {
  return (
    <div>applynow</div>
  )
}

export default applynow