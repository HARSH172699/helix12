import React from 'react'

const DirectHire = () => {
  return (
    <div>DirectHire</div>
  )
}

export default DirectHire